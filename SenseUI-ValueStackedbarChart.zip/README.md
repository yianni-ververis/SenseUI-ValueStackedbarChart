# SenseUI-ValueStackedbarChart
A simple Stacked bar Chart based on the value of the measure and not the number of measures
